import { createContext } from 'react';

const AnimationThemeContext = createContext();

export default AnimationThemeContext;
