import { createContext } from 'react';

const KanbanboardContext = createContext();

export default KanbanboardContext;
