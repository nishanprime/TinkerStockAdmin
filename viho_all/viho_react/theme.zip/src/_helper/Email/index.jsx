import { createContext } from 'react';

const EmailContext = createContext();

export default EmailContext;
