import { createContext } from 'react';

const CustomizerContext = createContext();

export default CustomizerContext;
